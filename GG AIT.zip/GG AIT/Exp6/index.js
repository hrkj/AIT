let object = document.getElementById("object");

function changeColor(color) {
    object.style.background = color;
}