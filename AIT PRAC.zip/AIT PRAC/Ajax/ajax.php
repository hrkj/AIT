<html>
	<head>
		<title>Home</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="text/javascript" src="ajax_demo.js"></script>
		<style type="text/css">
			
		</style>

	
	</head>
	<body class="body">
		
		<form>
				<label>
					<input type="button" name="submit" value="Submit" onclick="showhint();">
				</label>
		</form>
		<div id = "output">
			
		</div>
		
	</body>
</html>